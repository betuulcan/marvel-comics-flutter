import 'package:flutter/material.dart';
import 'package:marvelcomics/models/Characters.dart';

class CharacterDetail extends StatefulWidget {
  static const routeName = '/character-detail';
  @override
  _CharacterDetailState createState() => _CharacterDetailState();
}

class _CharacterDetailState extends State<CharacterDetail> {
  // var _loadedInitData = false;
  // Results results;

  // @override
  // void initState() {
  //   super.initState();
  // }

  // @override
  // void didChangeDependencies() {
  //   if (!_loadedInitData) {
  //     final routeArgs =
  //         ModalRoute.of(context).settings.arguments as Map<String, Results>;
  //     results = routeArgs['results'];
  //     _loadedInitData = true;
  //   }

  //   super.didChangeDependencies();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(categoryTitle),
      ),
    );
  }
}
